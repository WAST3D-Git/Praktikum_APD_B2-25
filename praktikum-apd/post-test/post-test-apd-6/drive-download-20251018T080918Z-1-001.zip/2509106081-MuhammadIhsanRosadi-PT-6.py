import os

users = {
    "mihsanr81": {"password": "2509106081", "role": "admin"}
}

projects = {}
project_id_counter = 1

while True:
    os.system('cls' if os.name == 'nt' else 'clear')
    print("=== SISTEM MANAJEMEN PROYEK DESAIN GRAFIS ===")
    print("1. Login")
    print("2. Register")
    print("3. Keluar")
    menu = input("Pilih menu: ")

    if menu == "1":
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=== LOGIN ===")
        username = input("Username: ")
        password = input("Password: ")
        user_ditemukan = None

        if username in users and users[username]["password"] == password:
            # Versi manual tanpa **
            user_ditemukan = {
                "username": username,
                "password": users[username]["password"],
                "role": users[username]["role"]
            }

        if user_ditemukan == None:
            print("Login gagal! Username atau password salah.")
            input("Tekan Enter Untuk Melanjutkan...")
            continue

        if user_ditemukan["role"] == "admin":
            while True:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("=== MENU ADMIN ===")
                print("1. Tambah Proyek")
                print("2. Lihat Proyek")
                print("3. Update Proyek")
                print("4. Hapus Proyek")
                print("5. Logout")
                pilih = input("Pilih: ")

                # TAMBAH PROYEK
                if pilih == "1":
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print("=== TAMBAH PROYEK ===")
                    judul = input("Judul: ")
                    deskripsi = input("Deskripsi: ")
                    software = input("Software: ")
                    deadline = input("Deadline: ")
                    klien = input("Klien: ")
                    status = input("Status: ")
                    if judul != "" and klien != "":
                        projects[project_id_counter] = {
                            "judul": judul,
                            "deskripsi": deskripsi,
                            "software": software,
                            "deadline": deadline,
                            "klien": klien,
                            "status": status
                        }
                        project_id_counter += 1
                        print("Proyek berhasil ditambah!")
                    else:
                        print("Wajib diisi!")
                    input("Tekan Enter Untuk Melanjutkan...")

                # LIHAT PROYEK
                elif pilih == "2":
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print("=== DAFTAR PROYEK ===")
                    if len(projects) == 0:
                        print("Belum ada proyek.")
                    else:
                        for index, (proyek_id, proyek) in enumerate(projects.items(), start=1):
                            print(f"\n[{index}] {proyek['judul']}")
                            print(f"Deskripsi: {proyek['deskripsi']}")
                            print(f"Software : {proyek['software']}")
                            print(f"Deadline : {proyek['deadline']}")
                            print(f"Klien    : {proyek['klien']}")
                            print(f"Status   : {proyek['status']}")
                    input("\nTekan Enter Untuk Melanjutkan...")

                # UPDATE PROYEK
                elif pilih == "3":
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print("=== UBAH PROYEK ===")
                    if len(projects) == 0:
                        print("Belum ada proyek.")
                        input("Tekan Enter Untuk Melanjutkan...")
                        continue

                    list_proyek = list(projects.items())
                    for index, (proyek_id, proyek) in enumerate(list_proyek, start=1):
                        print(f"[{index}] {proyek['judul']}")

                    nomor = input("\nPilih nomor proyek: ")
                    if nomor.isdigit():
                        nomor = int(nomor) - 1
                        if 0 <= nomor < len(list_proyek):
                            proyek_id = list_proyek[nomor][0]
                            proyek = projects[proyek_id]

                            while True:
                                os.system('cls' if os.name == 'nt' else 'clear')
                                print(f"=== UBAH PROYEK: {proyek['judul']} ===")
                                print("1. Judul")
                                print("2. Deskripsi")
                                print("3. Software")
                                print("4. Deadline")
                                print("5. Klien")
                                print("6. Status")
                                print("7. Selesai Update")
                                pilih_update = input("Pilih data yang ingin diubah: ")

                                if pilih_update == "1":
                                    proyek['judul'] = input("Masukkan judul baru: ")
                                elif pilih_update == "2":
                                    proyek['deskripsi'] = input("Masukkan deskripsi baru: ")
                                elif pilih_update == "3":
                                    proyek['software'] = input("Masukkan software baru: ")
                                elif pilih_update == "4":
                                    proyek['deadline'] = input("Masukkan deadline baru: ")
                                elif pilih_update == "5":
                                    proyek['klien'] = input("Masukkan nama klien baru: ")
                                elif pilih_update == "6":
                                    proyek['status'] = input("Masukkan status baru: ")
                                elif pilih_update == "7":
                                    break
                                else:
                                    print("Pilihan tidak valid!")
                                    input("Tekan Enter Untuk Melanjutkan...")

                            print("Data proyek berhasil diperbarui!")
                        else:
                            print("Nomor proyek tidak valid!")
                    else:
                        print("Input harus angka!")
                    input("Tekan Enter Untuk Melanjutkan...")

                # HAPUS PROYEK
                elif pilih == "4":
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print("=== HAPUS PROYEK ===")
                    if len(projects) == 0:
                        print("Belum ada proyek.")
                        input("Tekan Enter Untuk Melanjutkan...")
                        continue

                    list_proyek = list(projects.items())
                    for index, (proyek_id, proyek) in enumerate(list_proyek, start=1):
                        print(f"[{index}] {proyek['judul']}")

                    nomor = input("Pilih nomor proyek: ")
                    if nomor.isdigit():
                        nomor = int(nomor) - 1
                        if 0 <= nomor < len(list_proyek):
                            proyek_id = list_proyek[nomor][0]
                            hapus = input(f"Hapus proyek '{projects[proyek_id]['judul']}'? (y/n): ").lower()
                            if hapus == "y":
                                del projects[proyek_id]
                                print("Proyek dihapus!")
                            else:
                                print("Dibatalkan.")
                        else:
                            print("Nomor tidak valid.")
                    else:
                        print("Input harus angka.")
                    input("Tekan Enter Untuk Melanjutkan...")

                elif pilih == "5":
                    break
                else:
                    print("Pilihan tidak valid!")
                    input("Tekan Enter Untuk Melanjutkan...")

        # USER BIASA
        else:
            while True:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"=== MENU PENGGUNA ({user_ditemukan['username']}) ===")
                print("1. Lihat Proyek")
                print("2. Logout")
                pilih_user = input("Pilih: ")

                if pilih_user == "1":
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print("=== DAFTAR PROYEK ===")
                    if len(projects) == 0:
                        print("Belum ada proyek.")
                    else:
                        for index, (proyek_id, proyek) in enumerate(projects.items(), start=1):
                            print(f"\n[{index}] {proyek['judul']}")
                            print(f"Deskripsi: {proyek['deskripsi']}")
                            print(f"Software : {proyek['software']}")
                            print(f"Deadline : {proyek['deadline']}")
                            print(f"Klien    : {proyek['klien']}")
                            print(f"Status   : {proyek['status']}")
                    input("\nTekan Enter Untuk Melanjutkan...")
                elif pilih_user == "2":
                    break
                else:
                    print("Pilihan tidak valid!")
                    input("Tekan Enter Untuk Melanjutkan...")

    # REGISTER
    elif menu == "2":
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=== REGISTER ===")
        username = input("Username baru: ")
        password = input("Password: ")
        if username == "" or password == "":
            print("Username dan password wajib diisi!")
        elif username in users:
            print("Username sudah digunakan!")
        else:
            users[username] = {"password": password, "role": "user"}
            print("Akun berhasil dibuat!")
        input("Tekan Enter Untuk Melanjutkan...")

    # KELUAR
    elif menu == "3":
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Terima kasih telah menggunakan program ini.")
        break
    else:
        print("Pilihan tidak valid!")
        input("Tekan Enter Untuk Melanjutkan...")